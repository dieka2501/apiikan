<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use DB;
class Labi extends Model
{
    protected $table = 'survey_labi';
	protected $primaryKey = 'id';

	public function add($data)
	{
		return DB::table($this->table)->insertGetId($data);
	}

	public function get_id($id)
	{
		return Labi::find($id);
	}

	public function get_all()
	{
		return Labi::where('status',1)->orderBy('id','DESC')->get();
	}

	public function get_page()
	{
		return DB::table($this->table)
		->join('surveyor','survey_labi.surveyor_id','=','surveyor.id_surveyor')
		->where('status',1)->orderBy('id','DESC')->paginate(20);
	}

	public function edit($id,$data)
	{
		return Labi::where('id',$id)->update($data);
	}
}
