<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use DB;
class Karang extends Model
{
    protected $table = 'survey_karang';
	protected $primaryKey = 'id_karang';

	public function add($data)
	{
		return DB::table($this->table)->insertGetId($data);
	}

	public function get_id($id)
	{
		return Karang::find($id);
	}

	public function count_all()
	{
		return DB::table($this->table)->count();
	}

	public function get_page()
	{
		return DB::table($this->table)
		->join('surveyor','survey_karang.surveyor_id','=','surveyor.id_surveyor')
		->where('status',1)->orderBy('id_karang','DESC')->paginate(20);
	}

	public function edit($id,$data)
	{
		return Karang::where('id_karang',$id)->update($data);
	}
}
