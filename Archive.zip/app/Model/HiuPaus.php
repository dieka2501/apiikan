<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use DB;

class HiuPaus extends Model
{
    protected $table = 'survey_hiupaus';
	protected $primaryKey = 'id';

	public function add($data)
	{
		return DB::table($this->table)->insertGetId($data);
	}

	public function get_id($id)
	{
		return HiuPaus::find($id);
	}

	public function get_all()
	{
		return HiuPaus::where('status',1)->orderBy('id','DESC')->get();
	}

	public function get_page()
	{
		return DB::table($this->table)
		->join('surveyor','survey_hiupaus.surveyor_id','=','surveyor.id_surveyor')
		->where('status',1)->orderBy('id','DESC')->paginate(20);
	}

	public function edit($id,$data)
	{
		return HiuPaus::where('id',$id)->update($data);
	}
}
