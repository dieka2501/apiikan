<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use DB;
class HiuMartil extends Model
{
    protected $table = 'survey_hiu_martil';
	protected $primaryKey = 'id';

	public function add($data)
	{
		return DB::table($this->table)->insertGetId($data);
	}

	public function get_id($id)
	{
		return HiuMartil::find($id);
	}

	public function get_all()
	{
		return HiuMartil::where('status',1)->orderBy('id','DESC')->get();
	}

	public function get_page()
	{
		return DB::table($this->table)->where('status',1)
		->join('surveyor','survey_hiu_martil.surveyor_id','=','surveyor.id_surveyor')
		->orderBy('id','DESC')->paginate(20);
	}

	public function edit($id,$data)
	{
		return HiuMartil::where('id',$id)->update($data);
	}
}
