<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use DB;
class Login extends Model
{
    protected $table = 'login';
	protected $primaryKey = 'surveyor_id';
	
	public function add($data)
	{
		return \DB::table($this->table)->insert($data);
	}
	
	public function delete_surveyor_id($id)
	{
 		return \DB::table($this->table)->where('surveyor_id',$id)->delete();
 	}

 	public function get_code($code)
 	{
 		return \DB::table($this->table)->where('code_verify',$code)->first();
 	}
 	
 	public function update_code($code,$data)
 	{
 		return \DB::table($this->table)->where('code_verify',$code)->update($data);
 	}
 	
 	public function get_token($token)
 	{
 		return \DB::table($this->table)->where('token',$token)->first();
 	}

 	public function get_device_id($device_id)
 	{
 		return \DB::table($this->table)->where('device_id',$device_id)->first();
 	}
 	
 	public function del_device_id($device_id)
 	{
 		return \DB::table($this->table)->where('device_id',$device_id)->delete();
 	}
}
