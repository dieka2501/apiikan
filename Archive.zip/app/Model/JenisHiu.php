<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class JenisHiu extends Model
{
    protected $table 		= "jenis_hiu";
	protected $primaryKey 	= "id_jh";
	
	public function get_all()
	{
		return jenisHiu::all();
	}
}
