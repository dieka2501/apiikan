<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class JenisPenyu extends Model
{
    protected $table 		= "jenis_penyu";
	protected $primaryKey 	= "id_jp";
	
	public function get_all(){
		return JenisPenyu::all();
	}
}
