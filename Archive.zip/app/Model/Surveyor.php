<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use DB;

class Surveyor extends Model
{
	protected $table 		= 'surveyor';
	protected $primaryKey 	= 'id_surveyor';
	protected $fillable 	= ['surveyor_name','surveyor_email','instansi_id','instansi_name','password'
								,'date_insert','date_update','keyreset','surveyor_no_hape','surveyor_address'];
    //
	public function add($data)
	{
		return Surveyor::create($data);
	}

	public function get_email($email)
	{
		return \DB::table($this->table)->where('surveyor_email',$email)->first();
	}

	public function get_email_pass($email,$pass)
	{
		return \DB::table($this->table)->where('surveyor_email',$email)->where('password',$pass)->where('surveyor_status',1)->first();
	}

	public function edit_id($id,$data)
	{
		return \DB::table($this->table)->where('id_surveyor',$id)->update($data);
	}
	
	public function edit_key($key,$data)
	{
		return \DB::table($this->table)->where('keyreset',$key)->update($data);
	}

	public function edit_email($email,$data)
	{
		return \DB::table($this->table)->where('surveyor_email',$email)->update($data);
	}

	public function get_key($key)
	{
		return \DB::table($this->table)->where('keyreset',$key)->first();	
	}
}
