<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use DB;
class Napoleon extends Model
{
    protected $table = 'survey_napoleon';
	protected $primaryKey = 'id';

	public function add($data)
	{
		return DB::table($this->table)->insertGetId($data);
	}

	public function get_id($id)
	{
		return Napoleon::find($id);
	}

	public function count_all()
	{
		return DB::table($this->table)->count();
	}

	public function get_page()
	{
		return DB::table($this->table)
		->join('surveyor','survey_napoleon.surveyor_id','=','surveyor.id_surveyor')
		->where('status',1)->orderBy('id','DESC')->paginate(20);
	}

	public function edit($id,$data)
	{
		return Napoleon::where('id',$id)->update($data);
	}
}
