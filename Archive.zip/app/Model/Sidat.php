<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use DB;

class Sidat extends Model
{
    protected $table = 'survey_sidat';
	protected $primaryKey = 'id';

	public function add($data)
	{
		return DB::table($this->table)->insertGetId($data);
	}

	public function get_id($id)
	{
		return Sidat::find($id);
	}

	public function count_all()
	{
		return DB::table($this->table)->where('status',1)->count();
	}

	public function get_page()
	{
		return DB::table($this->table)
		->join('surveyor','survey_sidat.surveyor_id','=','surveyor.id_surveyor')
		->where('status',1)->orderBy('id','DESC')->paginate(20);
	}

	public function edit($id,$data)
	{
		return Sidat::where('id',$id)->update($data);
	}
}
