<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use DB;

class Bcf extends Model
{
    protected $table = 'survey_bcf';
	protected $primaryKey = 'id';

	public function add($data)
	{
		return DB::table($this->table)->insertGetId($data);
	}

	public function get_id($id)
	{
		return Bcf::find($id);
	}

	public function get_all()
	{
		return Bcf::orderBy('id','DESC')->where('status',1)->get();
	}

	public function get_page()
	{
		return DB::table($this->table)
		->join('surveyor','survey_bcf.surveyor_id','=','surveyor.id_surveyor')
		->orderBy('id','DESC')->where('status',1)->paginate(20);
	}

	public function edit($id,$data)
	{
		return Bcf::where('id',$id)->update($data);
	}
}
