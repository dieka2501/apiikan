<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use DB;

class Lola extends Model
{
    protected $table = 'survey_lola';
	protected $primaryKey = 'id';

	public function add($data)
	{
		return DB::table($this->table)->insertGetId($data);
	}

	public function get_id($id)
	{
		return Lola::find($id);
	}

	public function get_all(){
		return Lola::where('status',1)->orderBy('id','DESC')->get();
	}

	public function count_all(){
		return DB::table($this->table)->count();
	}

	public function get_page(){
		return DB::table($this->table)
		->join('surveyor','survey_lola.surveyor_id','=','surveyor.id_surveyor')
		->where('status',1)->orderBy('id','DESC')->paginate(20);
	}

	public function edit($id,$data){
		return Lola::where('id',$id)->update($data);
	}
}
