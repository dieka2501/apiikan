<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use DB;

class Dugong extends Model
{
    protected $table = 'survey_dugong';
	protected $primaryKey = 'id';

	public function add($data)
	{
		return DB::table($this->table)->insertGetId($data);
	}

	public function get_id($id)
	{
		return Dugong::find($id);
	}

	public function get_all()
	{
		return Dugong::where('status',1)->orderBy('id','DESC')->get();
	}

	public function get_page()
	{
		return DB::table($this->table)->where('status',1)
		->join('surveyor','survey_dugong.surveyor_id','=','surveyor.id_surveyor')
		->orderBy('id','DESC')->paginate(20);
	}

	public function edit($id,$data)
	{
		return Dugong::where('id',$id)->update($data);
	}
}
