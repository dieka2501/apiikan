<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use DB;

class Lokasi extends Model
{
    protected $table = 'lokasi';
	
	public static function provinsi($key)
	{
		$lokasi = Lokasi::where('lokasi_nama','like','%'.$key.'%')
		// ->where('lokasi_propinsi',0)
		->where('lokasi_kabupatenkota',0)
		->where('lokasi_kecamatan',0)
		->where('lokasi_kelurahan',0)
		->get();
		return $lokasi;
	}

	public static function kabupaten($key,$provinsi)
	{
		$lokasi = Lokasi::where('lokasi_nama','like','%'.$key.'%')
		->where('lokasi_propinsi',$provinsi)
		// ->where('lokasi_kabupatenkota',0)
		->where('lokasi_kecamatan',0)
		->where('lokasi_kelurahan',0)
		->get();
		return $lokasi;	
	}

	public static function kecamatan($key,$provinsi,$kabupaten)
	{
		$lokasi = Lokasi::where('lokasi_nama','like','%'.$key.'%')
		->where('lokasi_propinsi',$provinsi)
		->where('lokasi_kabupatenkota',$kabupaten)
		// ->where('lokasi_kecamatan',0)
		->where('lokasi_kelurahan',0)
		->get();
		return $lokasi;	
	}

	public static function kelurahan($key,$provinsi,$kabupaten,$kecamatan)
	{
		$lokasi = Lokasi::where('lokasi_nama','like','%'.$key.'%')
		->where('lokasi_propinsi',$provinsi)
		->where('lokasi_kabupatenkota',$kabupaten)
		->where('lokasi_kecamatan',$kecamatan)
		// ->where('lokasi_kelurahan',0)
		->get();
		return $lokasi;	
	}

	public function get_all_prov()
	{
		return DB::table($this->table)
				->where('lokasi_kabupatenkota',00)
				->where('lokasi_kecamatan',00)
				->where('lokasi_kelurahan',0000)
				->orderBy('lokasi_nama','ASC')
				->get();
	}

	public function get_kab_idprov($idprov)
	{
		return DB::table($this->table)
				->where('lokasi_propinsi',$idprov)
				->where('lokasi_kabupatenkota','!=',00)
				->where('lokasi_kecamatan',00)
				->where('lokasi_kelurahan',0000)
				->orderBy('lokasi_nama','ASC')
				->get();

	}

	public function get_prov_idprov($idprov)
	{
		return DB::table($this->table)
				->where('lokasi_propinsi',$idprov)
				->where('lokasi_kabupatenkota',00)
				->where('lokasi_kecamatan',00)
				->where('lokasi_kelurahan',0000)
				->orderBy('lokasi_nama','ASC')
				->first();		
	}

	public function get_kec_idcity($idprov,$idcity)
	{
		return DB::table($this->table)
				->where('lokasi_propinsi',$idprov)
				->where('lokasi_kabupatenkota',$idcity)
				->where('lokasi_kecamatan','!=',00)
				->where('lokasi_kelurahan',0000)
				->orderBy('lokasi_nama','ASC')
				->get();

	}

	public function get_city_idcity($idprov,$idcity)
	{
		return DB::table($this->table)
				->where('lokasi_propinsi',$idprov)
				->where('lokasi_kabupatenkota',$idcity)
				->where('lokasi_kecamatan',00)
				->where('lokasi_kelurahan',0000)
				->orderBy('lokasi_nama','ASC')
				->first();

	}

	public function get_kec_idkec($idprov,$idcity,$idkec)
	{
		return DB::table($this->table)
				->where('lokasi_propinsi',$idprov)
				->where('lokasi_kabupatenkota',$idcity)
				->where('lokasi_kecamatan',$idkec)
				->where('lokasi_kelurahan',0000)
				->orderBy('lokasi_nama','ASC')
				->first();		
	}

	public function get_kel_idkec($idprov,$idcity,$idkec)
	{
		return DB::table($this->table)
				->where('lokasi_propinsi',$idprov)
				->where('lokasi_kabupatenkota',$idcity)
				->where('lokasi_kecamatan',$idkec)
				->where('lokasi_kelurahan','!=',0000)
				->orderBy('lokasi_nama','ASC')
				->get();

	}

	public function get_kel_idkel($idprov,$idcity,$idkec,$idkel)
	{
		return DB::table($this->table)
				->where('lokasi_propinsi',$idprov)
				->where('lokasi_kabupatenkota',$idcity)
				->where('lokasi_kecamatan',$idkec)
				->where('lokasi_kelurahan',$idkel)
				->first();		
	}
}
