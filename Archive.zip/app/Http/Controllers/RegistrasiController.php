<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Model\Surveyor;

class RegistrasiController extends Controller
{
    //
    protected $model;
    public function __construct(Surveyor $model)
    {
		$this->model = $model;
			
	}

	public function register(Request $request)
	{
		if($request->has('email') && $request->has('password') && $request->has('instansi') && $request->has('fullname')){
			$email 		= $request->get('email');
			$password 	= $request->get('password');
			$repass 	= $request->get('repass');
			$instansi 	= $request->get('instansi');
			$name 		= $request->get('fullname');
			$name_ins 	= $request->get('name_instansi');
			$no_hp 		= $request->get('phone');
			$address 	= $request->get('address');
			if($password == $repass){
				$insert['surveyor_name'] 		= $name;
				$insert['surveyor_email'] 		= $email;
				$insert['surveyor_no_hape'] 	= $no_hp;
				$insert['surveyor_address'] 	= $address;
				$insert['instansi_id'] 			= $instansi;
				$insert['instansi_name'] 		= $name_ins;
				$insert['password']		 		= md5($password);
				$insert['created_at']		 	= date('Y-m-d H:i:s');
				$get_email = $this->model->get_email($email);
				if(count($get_email) == 0){
					$this->model->add($insert);
					$get_surveyor = $this->model->get_email($email);
					if(count($get_surveyor) > 0){
						$status = true;
						$data 	= $get_surveyor;
						$alert 	= "Data Surveyor Telah Disimpan";		
					}else{
						$status = false;
						$data 	= null;
						$alert 	= "Data Surveyor Tidak Tersimpan";		
					}
				}else{
					$status = false;
					$data 	= null;
					$alert 	= "Email sudah terdaftar";		
				}
				
			}else{
				$status = false;
				$data 	= null;
				$alert 	= "Password harus sama";	
			}
		}else{
			$status = false;
			$data 	= null;
			$alert 	= "Email, Password, Instansi dan Nama Lengkap  harus diisi";
		}
		$json = array('status'=>$status,'data'=>$data,'alert'=>$alert);
		return response()->json($json);
	}
}
