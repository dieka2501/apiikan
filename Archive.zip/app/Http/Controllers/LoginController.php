<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Model\Surveyor;
use App\Model\Login;

class LoginController extends Controller
{
   	protected $login;
   	protected $surveyor;

   	public function __construct(Login $login,Surveyor $surveyor)
   	{
		$this->login 		= $login;
		$this->surveyor 	= $surveyor;
	}

	public function login(Request $request)
	{
		if($request->has('email') && $request->has('password')){
			$email 		= $request->get('email');
			$pass 		= $request->get('password');
			$get_login 	= $this->surveyor->get_email_pass($email,md5($pass));
			if(count($get_login) > 0){
				$this->login->delete_surveyor_id($get_login->id_surveyor);
				$token 					=  md5($email.date('YmdHis'));
				$login['surveyor_id'] 	= $get_login->id_surveyor;
				$login['token'] 		= $token;
				$login['created_at'] 	= date('Y-m-d H:i:s');
				$login['updated_at'] 	= date('Y-m-d H:i:s');
				$this->login->add($login);
				$get_token = $this->login->get_token($token);
				if(count($get_token) > 0){
					$datalog 	= ['surveyor_id'=>$get_login->id_surveyor,'surveyor_name'=>$get_login->surveyor_name
									,'surveyor_email'=>$get_login->surveyor_email,'instansi_name'=>$get_login->instansi_name,
									'token'=>$get_token->token,'created_at'=>$get_token->created_at,'updated_at'=>$get_token->updated_at];
					$status 	= true;
					$data 		= $datalog;
					$alert 		= "Login berhasil";		
				}else{
					$status = false;
					$data 	= null;
					$alert 	= "Login gagal, kesalahan token";		
				}
			}else{
				$status = false;
				$data 	= null;
				$alert 	= "Login gagal. Email atau Password salah";	
			}
		}else{
			$status = false;
			$data 	= null;
			$alert 	= "Email dan Password harus diisi";
		}
		$json = array('status'=>$status,'data'=>$data,'alert'=>$alert);
		return response()->json($json);
	}
}
