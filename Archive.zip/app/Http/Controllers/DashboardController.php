<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Model\BambuLaut;
use App\Model\Bcf;
use App\Model\Dugong;
use App\Model\HiuMartil;
use App\Model\HiuPaus;
use App\Model\Kima;
use App\Model\KudaLaut;
use App\Model\Labi;
use App\Model\Lola;
use App\Model\Mola;
use App\Model\Napoleon;
use App\Model\Parimanta;
use App\Model\PausLumba;
use App\Model\Penyu;
use App\Model\Sidat;
use App\Model\Teripang;
use App\Model\Tukik;
use App\Model\Karang;


class DashboardController extends Controller
{
	protected $bambuLaut;
	protected $bcf;
	protected $dugong;
	protected $hiuMartil;
	protected $hiupaus;
	protected $kima;
	protected $kudalaut;
	protected $labi;
	protected $lola;
	protected $mola;
	protected $napoleon;
	protected $parimanta;
	protected $pauslumba;
	protected $penyu;
	protected $sidat;
	protected $teripang;
	protected $tukik;
	protected $karang;

    public function __construct(BambuLaut $bambuLaut, 
    							Bcf $bcf,
    							Dugong $dugong,
    							HiuMartil $hiuMartil,
    							HiuPaus $hiupaus,
    							Kima $kima,
    							KudaLaut $kudalaut,
    							Labi $labi,
    							Lola $lola,
    							Mola $mola,
    							Napoleon $napoleon,
    							PariManta $parimanta,
    							PausLumba $pauslumba,
    							Penyu $penyu,
    							Sidat $sidat,
    							Teripang $teripang,
    							Tukik $tukik,
    							Karang $karang
   								){
		$this->bambuLaut 	= $bambuLaut;
		$this->bcf 		 	= $bcf;
		$this->dugong 	 	= $dugong;
		$this->hiuMartil 	= $hiuMartil;
		$this->hiupaus 		= $hiupaus;
		$this->kima 		= $kima;
		$this->kudalaut		= $kudalaut;
		$this->labi			= $labi;
		$this->lola			= $lola;
		$this->mola			= $mola;
		$this->napoleon		= $napoleon;
		$this->parimanta 	= $parimanta;
		$this->pauslumba 	= $pauslumba;
		$this->penyu 		= $penyu;
		$this->sidat 		= $sidat;
		$this->teripang 	= $teripang;
		$this->tukik 		= $tukik;
		$this->karang 		= $karang;

	}
	public function dashboard(){
		$get_bambulaut 			= $this->bambuLaut->get_all();
		$countbambulaut 		= count($get_bambulaut);
		$get_bcf 				= $this->bcf->get_all();
		$countbcf 				= count($get_bcf);
		$get_dugong 			= $this->dugong->get_all();
		$countdugong 			= count($get_dugong);
		$get_hiumartil 			= $this->hiuMartil->get_all();
		$counthiumartil 		= count($get_hiumartil);
		$get_hiupaus 			= $this->hiupaus->get_all();
		$counthiupaus 			= count($get_hiupaus);
		$get_kima 				= $this->kima->get_all();
		$countkima 				= count($get_kima);
		$get_kudalaut 			= $this->kudalaut->get_all();
		$countkudalaut 			= count($get_kudalaut);
		$get_labi	 			= $this->labi->get_all();
		$countlabi 				= count($get_labi);
		$countlola 				= $this->lola->count_all();
		$countmola 				= $this->mola->count_all();
		$countnapoleon 			= $this->napoleon->count_all();
		$countparimanta			= $this->parimanta->count_all();
		$countpauslumba			= $this->pauslumba->count_all();
		$countpenyu				= $this->penyu->count_all();
		$countteripang			= $this->teripang->count_all();
		$counttukik				= $this->tukik->count_all();
		$countkarang			= $this->karang->count_all();

		$status = true;
		$data 	= array('bambulaut'=>$countbambulaut,'bcf'=>$countbcf,'dugong'=>$countdugong,'hiumartil'=>$counthiumartil,'hiupaus'=>$counthiupaus,
						'kima'=>$countkima,'kudalaut'=>$countkudalaut,'labi'=>$countlabi,'lola'=>$countlola,'mola'=>$countmola,'napoleon'=>$countnapoleon,
						'parimanta'=>$countparimanta,'pauslumba'=>$countpauslumba,'penyu'=>$countpenyu,'teripang'=>$countteripang,'tukik'=>$counttukik,
						'karang'=>$countkarang);
		$alert 	= "Data diketemukan";
		$json = array('status'=>$status,'data'=>$data,'alert'=>$alert);
		return response()->json($json);
	}
}
