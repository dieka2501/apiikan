<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Model\Surveyor;
use Mail;
class ResetPasswordController extends Controller
{
	protected $surveyor;

    public function __construct(Surveyor $surveyor)
    {
		$this->surveyor = $surveyor;
	}
	
	public function verifyemail(Request $request)
	{
		if($request->has('email')){
			$email 			= $request->get('email');
			$getemail 		= $this->surveyor->get_email($email);
			if(count($getemail)>0){
				$rand 				= substr(strtoupper(md5($getemail->password.date('ymdhis'))), 5,5);
				$viewemail['name'] 	= $getemail->surveyor_name;
				$viewemail['key'] 	= $rand;
				$viewemail['email']	= $getemail->surveyor_email;
				$detail['to'] 		= $getemail->surveyor_email;
				$detail['name'] 	= $getemail->surveyor_name;
				$detail['subject'] 	= "Permintaan Ubah Password";
				$emaildb['keyreset']	= $rand;
				$emaildb['updated_at']	= date('Y-m-d H:i:s');
				$this->surveyor->edit_email($getemail->surveyor_email,$emaildb);
				Mail::send('resetPassword',$viewemail,function($message) use ($detail){
					$message->from('administrator@bpspl-makassar.net','Administrator');
					$message->to($detail['to'],$detail['name'])->subject($detail['subject']);
				});

				$status 	= true;
				$data 		= $getemail;
				$alert 		= "Reset password berhasil, silakan periksa email Anda.";
			}else{
				$status = false;
				$data 	= null;
				$alert 	= "Email tidak diketemukan, silakan registrasi terlebih dahulu.";	
			}
		}else{
			$status = false;
			$data 	= null;
			$alert 	= "Paramater email tidak ada";
		}
		$json = array('status'=>$status,'data'=>$data,'alert'=>$alert);
		return response()->json($json);
	}
	function do_reset(Request $request){
		if($request->has('key') && $request->has('password')){
			$key 		= $request->get('key');
			$password 	= $request->get('password');
			$repass 	= $request->get('repass');
			if($password == $repass){
				$getkey 	= $this->surveyor->get_key($key);
				if(count($getkey)> 0){
					$editpass['password'] 	= md5($password);
					$editpass['updated_at'] = date('Y-m-d H:i:s');
					$editpass['keyreset'] 	= '';
					$edit = $this->surveyor->edit_key($key,$editpass);
					$status = true;
					$data 	= $getkey;
					$alert 	= "Ubah password berhasil.";		
				}else{
					$status = false;
					$data 	= null;
					$alert 	= "Key yang Anda masukan salah.";		
				}
			}else{
				$status = false;
				$data 	= null;
				$alert 	= "Password dan Konfirmasi Password tidak sama";	
			}
		}else{
			$status = false;
			$data 	= null;
			$alert 	= "Paramater key dan password tidak ada";
		}
		$json = array('status'=>$status,'data'=>$data,'alert'=>$alert);
		return response()->json($json);
	}
}
