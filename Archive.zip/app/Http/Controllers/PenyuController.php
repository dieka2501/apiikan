<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Model\Penyu;
use App\Model\JenisPenyu;
use App\Model\Lokasi;

class PenyuController extends Controller
{
    protected $penyu;
    protected $lokasi;
    protected $jp;
    protected $path;

    public function __construct(Penyu $penyu,Lokasi $lokasi,JenisPenyu $jp)
    {
		date_default_timezone_set('Asia/Jakarta');
		$this->penyu 	= $penyu;
		$this->lokasi 	= $lokasi;
		$this->jp 		= $jp;
		$this->path   	= base_path().'/assets/uploads/';
	}

	public function post_survey(Request $request){	
		if($request->has('surveyor_id') && $request->has('id_prov') && $request->has('id_kabkota') && $request->has('id_kecamatan') && $request->has('id_kelurahan')){

			$surveyor_id 			= $request->get('surveyor_id');
			$id_prov 				= $request->get('id_prov');
			$id_kabkota 			= $request->get('id_kabkota');
			$id_kecamatan 			= $request->get('id_kecamatan');
			$id_kelurahan 			= $request->get('id_kelurahan');
			$weather  				= $request->get('cuaca');
			$qty					= $request->get('qty');
			$coordinate				= $request->get('koordinat');
			$jenis					= $request->get('jenis');
			$p_lengkung_karapas		= $request->get('p_lengkung_karapas');
			$l_lengkung_karapas		= $request->get('l_lengkung_karapas');
			$tagging				= $request->get('tagging');
			$komensal				= $request->get('komensal');
			$telur					= $request->get('telur');
			$kerusakan				= $request->get('kerusakan');
			$lebar_jejak			= $request->get('lebar_jejak');
			$primer 				= $request->get('primer');	
			$note_sekunder 			= $request->get('note_sekunder');
			$notes 					= $request->get('notes');
			$island 				= $request->get('island');
			$nama_desa 				= $request->get('village_name');
			$date_survey 			= $request->get('date_survey');
			$qty_telur 				= $request->get('qty_telur');
			$description_kerusakan	= $request->get('description_kerusakan');
			$no_taging				= $request->get('no_taging');
			if($primer == 0){
				$status = 0;
			}else{
				$status = 1;
			}
			if($request->hasFile('image_seluruh')){
				$image_seluruh		= $request->file('image_seluruh');
				$filename_seluruh 	= date('YmdHis').'.png';
				$image_seluruh->move($this->path,$filename_seluruh);
				$insert['image_seluruh']	= $filename_seluruh;
			}
			if($request->hasFile('image_samping')){
				$image_samping		= $request->file('image_samping');
				$filename_samping 	= date('YmdHis').'.png';
				$image_samping->move($this->path,$filename_samping);
				$insert['image_samping']	= $filename_samping;
			}
			if($request->hasFile('image_jejak')){
				$image_jejak		= $request->file('image_jejak');
				$filename_jejak 	= date('YmdHis').'.png';
				$image_jejak->move($this->path,$filename_jejak);
				$insert['image_jejak']	= $filename_jejak;
			}
			if($request->hasFile('image_kondisi_pantai')){
				$image_kondisi_pantai		= $request->file('image_kondisi_pantai');
				$filename_kondisi_pantai 		= date('YmdHis').'.png';
				$image_kondisi_pantai->move($this->path,$filename_kondisi_pantai);
				$insert['image_kondisi_pantai']	= $filename_kondisi_pantai;
			}
			$insert['primer'] 				= $primer;
			$insert['note_secunder']		= $note_sekunder;
			$insert['island']				= $island;
			$insert['village_name']			= $nama_desa;
			$insert['date_survey']			= $date_survey;
			$insert['status']				= $status;
			$insert['notes'] 				= $notes;
			$insert['description_kerusakan']= $description_kerusakan;
			$insert['qty_telur']			= $qty_telur;
			$insert['no_taging']			= $no_taging;
			$insert['surveyor_id'] 			= $surveyor_id;
			$insert['province_id'] 			= $id_prov;
			$insert['city_id'] 				= $id_kabkota;
			$insert['district_id'] 			= $id_kecamatan;
			$insert['village_id'] 			= $id_kelurahan;
			$insert['weather'] 				= $weather;
			$insert['qty'] 					= $qty;
			$insert['telur'] 				= $telur;
			$insert['kerusakan'] 			= $kerusakan;
			$insert['coordinate'] 			= $coordinate;
			$insert['jenis'] 				= $jenis;
			$insert['p_lengkung_karapas'] 	= $p_lengkung_karapas;
			$insert['l_lengkung_karapas'] 	= $l_lengkung_karapas;
			$insert['tagging'] 				= $tagging;
			$insert['komensal']				= $komensal;
			$insert['lebar_jejak']			= $lebar_jejak;
			$insert['created_at'] 			= date('Y-m-d H:i:s');
			$insert['updated_at'] 			= date('Y-m-d H:i:s');
			$ids 							= $this->penyu->add($insert);
			if($ids > 0){
				$get_data 				= $this->penyu->get_id($ids);
				$get_prov 				= $this->lokasi->get_prov_idprov($get_data->province_id);
				$get_city 				= $this->lokasi->get_city_idcity($get_data->province_id,$get_data->city_id);
				$get_district 			= $this->lokasi->get_kec_idkec($get_data->province_id,$get_data->city_id,$get_data->district_id);
				// $get_village 			= $this->lokasi->get_kel_idkel($get_data->province_id,$get_data->city_id,$get_data->district_id,$get_data->village_id);
				$json 					= ['id_penyu' => $ids,'prov_id'=>$get_data->province_id,'prov_name'=>$get_prov->lokasi_nama,'city_id'=>$get_data->city_id,'city_name'=>$get_city->lokasi_nama,
										   'district_id'=>$get_data->district_id,'district_name'=>$get_district->lokasi_nama,'village_name'=>$get_data->village_name,
										   'weather'=>$get_data->weather,'qty'=>$get_data->qty,'coordinate'=>$get_data->coordinate,
										   'jenis'=>$get_data->jenis,'p_lengkung_karapas'=>$get_data->p_lengkung_karapas,'l_lengkung_karapas'=>$get_data->l_lengkung_karapas,'tagging'=>$get_data->tagging,
										   'komensal'=>$get_data->komensal,'lebar_jejak'=>$get_data->lebar_jejak,'telur'=>$get_data->telur,'kerusakan'=>$get_data->kerusakan,
										   'image_seluruh'=>config('app.url').'/assets/uploads/'.$get_data->image_seluruh,
										   'image_samping'=>config('app.url').'/assets/uploads/'.$get_data->image_samping,
										   'image_jejak'=>config('app.url').'/assets/uploads/'.$get_data->image_jejak,
										   'image_kondisi_pantai'=>config('app.url').'/assets/uploads/'.$get_data->image_kondisi_pantai,
										   'created_at'=>$get_data->created_at];
				$status = true;
				$data 	= $json;
				$alert 	= "Insert data berhasil";	
			}else{
				$status = false;
				$data 	= null;
				$alert 	= "Insert data gagal";	
			}
		}else{
			$status = false;
			$data 	= null;
			$alert 	= "Paramater surveyor_id, id_prov, id_kabkota, id_kecamatan, dan id_kelurahan tidak ada";
		}
		$json = array('status'=>$status,'data'=>$data,'alert'=>$alert);
		return response()->json($json);
	}
	
	public function get_list(Request $request){
		$data = $this->penyu->get_page();
		// var_dump($getdata);
		if(count($data) > 0){
			foreach ($data as $get_data) {
				$get_prov 				= $this->lokasi->get_prov_idprov($get_data->province_id);
				$get_city 				= $this->lokasi->get_city_idcity($get_data->province_id,$get_data->city_id);
				$get_district 			= $this->lokasi->get_kec_idkec($get_data->province_id,$get_data->city_id,$get_data->district_id);
				// $get_village 			= $this->lokasi->get_kel_idkel($get_data->province_id,$get_data->city_id,$get_data->district_id,$get_data->village_id);
				$json[] 				= ['id_penyu' => $get_data->id,'id_surveyor'=>$get_data->surveyor_id,
											'surveyor_name'=>$get_data->surveyor_name,
											'prov_id'=>$get_data->province_id,'prov_name'=>$get_prov->lokasi_nama,'city_id'=>$get_data->city_id,'city_name'=>$get_city->lokasi_nama,
										   'district_id'=>$get_data->district_id,'district_name'=>$get_district->lokasi_nama,'village_name'=>$get_data->village_name,
										   'weather'=>$get_data->weather,'qty'=>$get_data->qty,'coordinate'=>$get_data->coordinate,
										   'jenis'=>$get_data->jenis,'p_lengkung_karapas'=>$get_data->p_lengkung_karapas,'l_lengkung_karapas'=>$get_data->l_lengkung_karapas,'tagging'=>$get_data->tagging,
										   'komensal'=>$get_data->komensal,'lebar_jejak'=>$get_data->lebar_jejak,'telur'=>$get_data->telur,'kerusakan'=>$get_data->kerusakan,
										   'status'=>$get_data->status,
										   'primer'=>$get_data->primer,
										   'note_secunder'=>$get_data->note_secunder,
										   'notes'=>$get_data->notes,
										   'island'=>$get_data->island,
										   'date_survey'=>$get_data->date_survey,
										   'qty_telur'=>$get_data->qty_telur,
										   'description_kerusakan'=>$get_data->description_kerusakan,
										   'no_taging'=>$get_data->no_taging,
										   'image_seluruh'=>config('app.url').'/assets/uploads/'.$get_data->image_seluruh,
										   'image_samping'=>config('app.url').'/assets/uploads/'.$get_data->image_samping,
										   'image_jejak'=>config('app.url').'/assets/uploads/'.$get_data->image_jejak,
										   'image_kondisi_pantai'=>config('app.url').'/assets/uploads/'.$get_data->image_kondisi_pantai,
										   'created_at'=>$get_data->created_at];
			}
			$status = true;
			$data 	= $json;
			$alert 	= "Data Penyu Diketemukan.";
		}else{
			$status = false;
			$data 	= array();
			$alert 	= "Data Penyu Belum Diketemukan.";
		}
		$json = array('status'=>$status,'data'=>$data,'alert'=>$alert);
		return response()->json($json);
	}
	public function get_jenis_penyu(Request $request){
		$get_jp 			= $this->jp->get_all();
		if(count($get_jp) > 0){
			$status = true;
			$arr 	= [];
			foreach ($get_jp as $jps) {
				$arr[] = ['id_jp'=>$jps->id_jp,'nama_jp'=>$jps->nama_jp,'deskripsi_jp'=>$jps->deskripsi_jp,'image_jp'=>config('app.url').'/assets/uploads/'.$jps->image_jp,
							'created_at'=>$jps->created_at,'updated_at'=>$jps->updated_at,'deleted_at'=>$jps->deleted_at];
			}
			$data 	= $arr;
			$alert 	= "Data Jenis Penyu Diketemukan.";
		}else{
			$status = false;
			$data 	= array();
			$alert 	= "Data Jenis Penyu Belum Diketemukan.";
		}
		$json 		= array('status'=>$status,'data'=>$data,'alert'=>$alert);
		return response()->json($json);	
	}

	public function get_id(Request $request){
		if($request->has('id') && $request->has('id_surveyor')){
			$id 			= $request->get('id');
			$id_surveyor 	= $request->get('id_surveyor');
			$get_penyu 		= $this->penyu->get_id($id);
			if(count($get_penyu) > 0){
				if($get_penyu->surveyor_id == $id_surveyor){
					$status = true;
					$data 	= $get_penyu;
					$alert 	= "Data diketemukan.";			
				}else{
					$status = false;
					$data 	= null;
					$alert 	= "Surveyor tidak diizinkan untuk mengedit data ini.";			
				}
			}else{
				$status = false;
				$data 	= null;
				$alert 	= "Data survey tidak diketemukan.";		
			}
		}else{
			$status = false;
			$data 	= null;
			$alert 	= "Paramater id dan id_surveyor tidak diketemukan.";	
		}
		$json = array('status'=>$status,'data'=>$data,'alert'=>$alert);
		return response()->json($json);
	}
	
	public function edit(Request $request){
		if($request->has('id') && $request->has('id_prov') && $request->has('id_kabkota') && $request->has('id_kecamatan')){
			$id 					= $request->get('id');
			$surveyor_id 			= $request->get('surveyor_id');
			$id_prov 				= $request->get('id_prov');
			$id_kabkota 			= $request->get('id_kabkota');
			$id_kecamatan 			= $request->get('id_kecamatan');
			$id_kelurahan 			= $request->get('id_kelurahan');
			$weather  				= $request->get('cuaca');
			$qty					= $request->get('qty');
			$coordinate				= $request->get('koordinat');
			$jenis					= $request->get('jenis');
			$p_lengkung_karapas		= $request->get('p_lengkung_karapas');
			$l_lengkung_karapas		= $request->get('l_lengkung_karapas');
			$tagging				= $request->get('tagging');
			$komensal				= $request->get('komensal');
			$telur					= $request->get('telur');
			$kerusakan				= $request->get('kerusakan');
			$lebar_jejak			= $request->get('lebar_jejak');
			$primer 				= $request->get('primer');	
			$note_sekunder 			= $request->get('note_sekunder');
			$notes 					= $request->get('notes');
			$island 				= $request->get('island');
			$nama_desa 				= $request->get('village_name');
			$date_survey 			= $request->get('date_survey');
			$qty_telur 				= $request->get('qty_telur');
			$description_kerusakan	= $request->get('description_kerusakan');
			$no_taging				= $request->get('no_taging');
			if($primer == 0){
				$status = 0;
			}else{
				$status = 1;
			}
			if($request->hasFile('image_seluruh')){
				$image_seluruh		= $request->file('image_seluruh');
				$filename_seluruh 	= date('YmdHis').'.png';
				$image_seluruh->move($this->path,$filename_seluruh);
				$insert['image_seluruh']	= $filename_seluruh;
			}
			if($request->hasFile('image_samping')){
				$image_samping		= $request->file('image_samping');
				$filename_samping 	= date('YmdHis').'.png';
				$image_samping->move($this->path,$filename_samping);
				$insert['image_samping']	= $filename_samping;
			}
			if($request->hasFile('image_jejak')){
				$image_jejak		= $request->file('image_jejak');
				$filename_jejak 	= date('YmdHis').'.png';
				$image_jejak->move($this->path,$filename_jejak);
				$insert['image_jejak']	= $filename_jejak;
			}
			if($request->hasFile('image_kondisi_pantai')){
				$image_kondisi_pantai		= $request->file('image_kondisi_pantai');
				$filename_kondisi_pantai 		= date('YmdHis').'.png';
				$image_kondisi_pantai->move($this->path,$filename_kondisi_pantai);
				$insert['image_kondisi_pantai']	= $filename_kondisi_pantai;
			}
			$insert['primer'] 				= $primer;
			$insert['note_secunder']		= $note_sekunder;
			$insert['island']				= $island;
			$insert['village_name']			= $nama_desa;
			$insert['date_survey']			= $date_survey;
			$insert['status']				= $status;
			$insert['notes'] 				= $notes;
			$insert['description_kerusakan']= $description_kerusakan;
			$insert['qty_telur']			= $qty_telur;
			$insert['no_taging']			= $no_taging;
			$insert['surveyor_id'] 			= $surveyor_id;
			$insert['province_id'] 			= $id_prov;
			$insert['city_id'] 				= $id_kabkota;
			$insert['district_id'] 			= $id_kecamatan;
			$insert['village_id'] 			= $id_kelurahan;
			$insert['weather'] 				= $weather;
			$insert['qty'] 					= $qty;
			$insert['telur'] 				= $telur;
			$insert['kerusakan'] 			= $kerusakan;
			$insert['coordinate'] 			= $coordinate;
			$insert['jenis'] 				= $jenis;
			$insert['p_lengkung_karapas'] 	= $p_lengkung_karapas;
			$insert['l_lengkung_karapas'] 	= $l_lengkung_karapas;
			$insert['tagging'] 				= $tagging;
			$insert['komensal']				= $komensal;
			$insert['lebar_jejak']			= $lebar_jejak;
			$insert['updated_at'] 			= date('Y-m-d H:i:s');
			if($this->penyu->edit($id,$insert)){
				$get_data 				= $this->penyu->get_id($id);
				$get_prov 				= $this->lokasi->get_prov_idprov($get_data->province_id);
				$get_city 				= $this->lokasi->get_city_idcity($get_data->province_id,$get_data->city_id);
				$get_district 			= $this->lokasi->get_kec_idkec($get_data->province_id,$get_data->city_id,$get_data->district_id);
				// $get_village 			= $this->lokasi->get_kel_idkel($get_data->province_id,$get_data->city_id,$get_data->district_id,$get_data->village_id);
				$json 					= ['id_penyu' => $id,'prov_id'=>$get_data->province_id,'prov_name'=>$get_prov->lokasi_nama,'city_id'=>$get_data->city_id,'city_name'=>$get_city->lokasi_nama,
										   'district_id'=>$get_data->district_id,'district_name'=>$get_district->lokasi_nama,'village_name'=>$get_data->village_name,
										   'weather'=>$get_data->weather,'qty'=>$get_data->qty,'coordinate'=>$get_data->coordinate,
										   'jenis'=>$get_data->jenis,'p_lengkung_karapas'=>$get_data->p_lengkung_karapas,'l_lengkung_karapas'=>$get_data->l_lengkung_karapas,'tagging'=>$get_data->tagging,
										   'komensal'=>$get_data->komensal,'lebar_jejak'=>$get_data->lebar_jejak,'telur'=>$get_data->telur,'kerusakan'=>$get_data->kerusakan,
										   'image_seluruh'=>config('app.url').'/assets/uploads/'.$get_data->image_seluruh,
										   'image_samping'=>config('app.url').'/assets/uploads/'.$get_data->image_samping,
										   'image_jejak'=>config('app.url').'/assets/uploads/'.$get_data->image_jejak,
										   'image_kondisi_pantai'=>config('app.url').'/assets/uploads/'.$get_data->image_kondisi_pantai,
										   'created_at'=>$get_data->created_at];
				$status = true;
				$data 	= $json;
				$alert 	= "Update data berhasil";	
			}else{
				$status = false;
				$data 	= null;
				$alert 	= "Paramater id.";			
			}
		}else{
			$status = false;
			$data 	= null;
			$alert 	= "Paramater id.";		
		}
		$json = array('status'=>$status,'data'=>$data,'alert'=>$alert);
		return response()->json($json);
	}


}
