<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Model\Lokasi;

class LokasiController extends Controller
{
	protected $lokasi;

    public function __construct(Lokasi $lokasi)
    {
		$this->lokasi = new lokasi;
		date_default_timezone_set('Asia/Jakarta');
	}

	public function get_provinsi_all(Request $request){
		$get_data = $this->lokasi->get_all_prov();
		if(count($get_data)>0){
			$status = true;
			$data 	= $get_data;
			$alert 	= "Data diketemukan";
		}else{
			$status = false;
			$data 	= array();
			$alert 	= "Data tidak diketemukan";
		}
		$json = array('status'=>$status,'data'=>$data,'alert'=>$alert);
		return response()->json($json);
	}
	public function get_kab_kota(Request $request){
		if($request->has('id_prov')){
			$idprov 	= $request->get('id_prov');
			$get_data = $this->lokasi->get_kab_idprov($idprov);
			if(count($get_data) > 0){
				$status = true;
				$data 	= $get_data;
				$alert 	= "Data diketemukan";	
			}else{
				$status = false;
				$data 	= array();
				$alert 	= "Data tidak diketemukan";		
			}
		}else{
			$status = false;
			$data 	= array();
			$alert 	= "Paramater id_prov tidak ada";
		}
		$json = array('status'=>$status,'data'=>$data,'alert'=>$alert);
		return response()->json($json);
	}

	public function get_kecamatan(Request $request){
		if($request->has('id_prov') && $request->has('id_kabkota')){
			$idprov 	= $request->get('id_prov');
			$idkabkota 	= $request->get('id_kabkota');
			$get_data = $this->lokasi->get_kec_idcity($idprov,$idkabkota);
			if(count($get_data) > 0){
				$status = true;
				$data 	= $get_data;
				$alert 	= "Data diketemukan";	
			}else{
				$status = false;
				$data 	= array();
				$alert 	= "Data tidak diketemukan";		
			}
		}else{
			$status = false;
			$data 	= array();
			$alert 	= "Paramater id_prov dan id_kabkota tidak ada";
		}
		$json = array('status'=>$status,'data'=>$data,'alert'=>$alert);
		return response()->json($json);
	}

	public function get_kelurahan(Request $request){
		if($request->has('id_prov') && $request->has('id_kabkota') && $request->has('id_kecamatan')){
			$idprov 	= $request->get('id_prov');
			$idkabkota 	= $request->get('id_kabkota');
			$idkec 		= $request->get('id_kecamatan');
			$get_data = $this->lokasi->get_kel_idkec($idprov,$idkabkota,$idkec);
			if(count($get_data) > 0){
				$status = true;
				$data 	= $get_data;
				$alert 	= "Data diketemukan";	
			}else{
				$status = false;
				$data 	= array();
				$alert 	= "Data tidak diketemukan";		
			}
		}else{
			$status = false;
			$data 	= array();
			$alert 	= "Paramater id_prov, id_kabkota dan id_kecamatan tidak ada";
		}
		$json = array('status'=>$status,'data'=>$data,'alert'=>$alert);
		return response()->json($json);
	}
}
