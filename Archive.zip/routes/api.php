<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::group(array('prefix'=>'/v1'),function(){
	//Instansi
	Route::get('/instansi/all','InstansiController@get_all');

	//Register
	Route::post('/register','RegistrasiController@register');

	//login
	Route::post('/login','LoginController@login');

	//Reset Password
	Route::post('/resetpass','ResetPasswordController@verifyemail');

	//Do Reset Password
	Route::post('/resetpass/do','ResetPasswordController@do_reset');

	//Get Provinsi
	Route::get('/province/all','LokasiController@get_provinsi_all');	

	//Get Kabupaten
	Route::get('/city','LokasiController@get_kab_kota');

	//Get Kecamatan
	Route::get('/district','LokasiController@get_kecamatan');	

	//Get Kelurahan
	Route::get('/village','LokasiController@get_kelurahan');	

	//Get Jenis Penyu
	Route::get('/penyu/jenis','PenyuController@get_jenis_penyu');	

	//Get Jenis Hiu
	Route::get('/hiu/jenis','HiuMartilController@get_jenis_hiu');	

	Route::group(['middleware'=>['token']],function(){
		//Karang
		Route::post('/karang/post','karangController@post_survey');	
		Route::get('/karang/list','karangController@get_list');	
		Route::get('/karang/id','karangController@get_id');	
		Route::post('/karang/edit','karangController@edit');	

		//Hiu Paus
		Route::post('/hiupaus/post','hiupausController@post_survey');	
		Route::get('/hiupaus/list','hiupausController@get_list');
		Route::get('/hiupaus/id','hiupausController@get_id');	
		Route::post('/hiupaus/edit','hiupausController@edit');	

		//Pari Manta
		Route::post('/parimanta/post','parimantaController@post_survey');	
		Route::get('/parimanta/list','parimantaController@get_list');
		Route::get('/parimanta/id','parimantaController@get_id');	
		Route::post('/parimanta/edit','parimantaController@edit');

		//Penyu
		Route::post('/penyu/post','penyuController@post_survey');
		Route::get('/penyu/list','penyuController@get_list');
		Route::get('/penyu/id','penyuController@get_id');	
		Route::post('/penyu/edit','penyuController@edit');	

		//Tukik
		Route::post('/tukik/post','tukikController@post_survey');	
		Route::get('/tukik/list','tukikController@get_list');
		Route::get('/tukik/id','tukikController@get_id');	
		Route::post('/tukik/edit','tukikController@edit');
			
		//Napoleon
		Route::post('/napoleon/post','napoleonController@post_survey');	
		Route::get('/napoleon/list','napoleonController@get_list');
		Route::get('/napoleon/id','napoleonController@get_id');	
		Route::post('/napoleon/edit','napoleonController@edit');

		//Dugong
		Route::post('/dugong/post','dugongController@post_survey');	
		Route::get('/dugong/list','dugongController@get_list');
		Route::get('/dugong/id','dugongController@get_id');	
		Route::post('/dugong/edit','dugongController@edit');	

		//Paus Lumba-lumba
		Route::post('/pauslumba/post','pausLumbaController@post_survey');	
		Route::get('/pauslumba/list','pausLumbaController@get_list');	
		Route::get('/pauslumba/id','pausLumbaController@get_id');	
		Route::post('/pauslumba/edit','pausLumbaController@edit');

		//Bambu Laut
		Route::post('/bambulaut/post','bambuLautController@post_survey');	
		Route::get('/bambulaut/list','bambuLautController@get_list');	
		Route::get('/bambulaut/id','bambuLautController@get_id');	
		Route::post('/bambulaut/edit','bambuLautController@edit');	
		//Kima
		Route::post('/kima/post','kimaController@post_survey');	
		Route::get('/kima/list','kimaController@get_list');
		Route::get('/kima/id','kimaController@get_id');	
		Route::post('/kima/edit','kimaController@edit');	
			
		//Lola
		Route::post('/lola/post','lolaController@post_survey');	
		Route::get('/lola/list','lolaController@get_list');
		Route::get('/lola/id','lolaController@get_id');	
		Route::post('/lola/edit','lolaController@edit');	

		//Kuda Laut
		Route::post('/kudalaut/post','kudaLautController@post_survey');	
		Route::get('/kudalaut/list','kudaLautController@get_list');	
		Route::get('/kudalaut/id','kudaLautController@get_id');	
		Route::post('/kudalaut/edit','kudaLautController@edit');	

		//Bcf
		Route::post('/bcf/post','bcfController@post_survey');	
		Route::get('/bcf/list','bcfController@get_list');	
		Route::get('/bcf/id','bcfController@get_id');
		Route::post('/bcf/edit','bcfController@edit');	

		//mola
		Route::post('/mola/post','molaController@post_survey');	
		Route::get('/mola/list','molaController@get_list');	
		Route::get('/mola/id','molaController@get_id');	
		Route::post('/mola/edit','molaController@edit');	

		//sidat
		Route::post('/sidat/post','sidatController@post_survey');	
		Route::get('/sidat/list','sidatController@get_list');	
		Route::get('/sidat/id','sidatController@get_id');	
		Route::post('/sidat/edit','sidatController@edit');	

		//Teripang
		Route::post('/teripang/post','teripangController@post_survey');	
		Route::get('/teripang/list','teripangController@get_list');	
		Route::get('/teripang/id','teripangController@get_id');	
		Route::post('/teripang/edit','teripangController@edit');

		//Labi-labi
		Route::post('/labi/post','labiController@post_survey');
		Route::get('/labi/list','labiController@get_list');	
		Route::get('/labi/id','labiController@get_id');	
		Route::post('/labi/edit','labiController@edit');	

		//Hiu Martil
		Route::post('/hiumartil/post','hiuMartilController@post_survey');
		Route::get('/hiumartil/list','hiuMartilController@get_list');
		Route::get('/hiumartil/id','hiuMartilController@get_id');	
		Route::post('/hiumartil/edit','hiuMartilController@edit');	

		//Dashboard
		Route::get('/dashboard','dashboardController@dashboard');	

	});
});

